# Evidence (Illustrative)

The following block shows **example** Jest output you can include in your report to illustrate passing tests. 
This is **sample output** and not generated here automatically.

Example Jest output:
```
 PASS  tests/unit.saveNote.test.js
  ✓ saveNote alerts when title or content are empty (5 ms)
  ✓ saveNote adds a note to the page when both fields provided (2 ms)
 PASS  tests/integration.saveButton.test.js
  ✓ typing a note and clicking Save Note shows the note on the page (8 ms)
 PASS  tests/system.flow.test.js
  ✓ full create → edit → save → delete flow (24 ms)

Test Suites: 3 passed, 3 total
Tests:       4 passed, 4 total
Snapshots:   0 total
Time:        2.345 s
```

_Note:_ To produce real output, run the tests locally (see README.md) or push this repo to GitHub and enable Actions — the included workflow will run the tests on each push.
