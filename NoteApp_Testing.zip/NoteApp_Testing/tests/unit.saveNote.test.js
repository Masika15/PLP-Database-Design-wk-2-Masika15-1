// tests/unit.saveNote.test.js
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const html = fs.readFileSync(path.resolve(__dirname, '../index.html'), 'utf8');

let dom;
beforeEach(() => {
  dom = new JSDOM(html, { runScripts: "dangerously", resources: "usable" });
  global.window = dom.window;
  global.document = dom.window.document;
});

afterEach(() => {
  dom.window.close();
  delete global.window;
  delete global.document;
});

test('saveNote alerts when title or content are empty', () => {
  window.alert = jest.fn();
  const titleInput = document.getElementById('note-title');
  const contentInput = document.getElementById('note-content');
  titleInput.value = '';
  contentInput.value = '';
  // call the app function
  window.saveNote();
  expect(window.alert).toHaveBeenCalledWith("Please fill in both fields.");
});

test('saveNote adds a note to the page when both fields provided', () => {
  const titleInput = document.getElementById('note-title');
  const contentInput = document.getElementById('note-content');
  titleInput.value = 'Unit Test Title';
  contentInput.value = 'Unit test content';
  window.saveNote();
  const notes = document.querySelectorAll('.note');
  expect(notes.length).toBe(1);
  expect(notes[0].querySelector('h3').textContent).toBe('Unit Test Title');
  expect(notes[0].querySelector('p').textContent).toBe('Unit test content');
});
