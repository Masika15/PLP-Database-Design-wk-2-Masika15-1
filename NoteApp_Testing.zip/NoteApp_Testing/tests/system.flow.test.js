// tests/system.flow.test.js
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const html = fs.readFileSync(path.resolve(__dirname, '../index.html'), 'utf8');

let dom;
beforeEach(() => {
  dom = new JSDOM(html, { runScripts: "dangerously", resources: "usable" });
  global.window = dom.window;
  global.document = dom.window.document;
});

afterEach(() => {
  dom.window.close();
  delete global.window;
  delete global.document;
});

test('full create → edit → save → delete flow (system test)', () => {
  // Create
  document.getElementById('note-title').value = 'Flow Title';
  document.getElementById('note-content').value = 'Flow content';
  const saveBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.trim() === 'Save Note');
  saveBtn.click();
  expect(document.querySelectorAll('.note').length).toBe(1);

  // Edit (click the Edit button inside the note)
  const editBtn = Array.from(document.querySelectorAll('.note button')).find(b => b.textContent.trim() === 'Edit');
  expect(editBtn).toBeDefined();
  editBtn.click();

  // After clicking edit the app repopulates the inputs and deletes the original note
  expect(document.querySelectorAll('.note').length).toBe(0);
  expect(document.getElementById('note-title').value).toBe('Flow Title');
  expect(document.getElementById('note-content').value).toBe('Flow content');

  // Save edited note (it will be saved as a new note)
  saveBtn.click();
  expect(document.querySelectorAll('.note').length).toBe(1);
  const note = document.querySelector('.note');
  expect(note.querySelector('h3').textContent).toBe('Flow Title');

  // Delete the note
  const deleteBtn = Array.from(document.querySelectorAll('.note button')).find(b => b.textContent.trim() === 'Delete');
  expect(deleteBtn).toBeDefined();
  deleteBtn.click();
  expect(document.querySelectorAll('.note').length).toBe(0);
});
