// tests/integration.saveButton.test.js
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const html = fs.readFileSync(path.resolve(__dirname, '../index.html'), 'utf8');

let dom;
beforeEach(() => {
  dom = new JSDOM(html, { runScripts: "dangerously", resources: "usable" });
  global.window = dom.window;
  global.document = dom.window.document;
});

afterEach(() => {
  dom.window.close();
  delete global.window;
  delete global.document;
});

test('typing a note and clicking Save Note shows the note on the page (integration)', () => {
  document.getElementById('note-title').value = 'Integration Title';
  document.getElementById('note-content').value = 'Integration content';
  // Find Save Note button (the one on the top)
  const saveBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.trim() === 'Save Note');
  expect(saveBtn).toBeDefined();
  saveBtn.click();
  const note = document.querySelector('.note');
  expect(note).not.toBeNull();
  expect(note.querySelector('h3').textContent).toBe('Integration Title');
  expect(note.querySelector('p').textContent).toBe('Integration content');
});
