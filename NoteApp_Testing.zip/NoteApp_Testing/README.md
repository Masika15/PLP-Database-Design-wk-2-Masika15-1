# NoteApp_Testing — Ready-to-submit folder (Beginner-friendly)

This folder contains testing artifacts for the Week 2 Functional Testing Lab.

## What is included
- `index.html` (the app you provided)
- `tests/` (3 Jest test files: unit, integration, system)
- `package.json` (devDeps: jest, jsdom)
- `Test_Report.md` (completed report, ready to submit)
- `GitHub_Issues.md` (three issues you can paste into GitHub)
- `EVIDENCE.md` (illustrative sample of Jest output)
- `.github/workflows/nodejs.yml` (CI workflow to run tests on GitHub Actions)

## Option A — Submit this folder as a ZIP to your LMS (quick)
1. Download `NoteApp_Testing.zip` from this package.
2. Upload the ZIP to your LMS as your assignment submission.
3. In the LMS submission comment, be honest: mention the tests are prepared and ready to run. Example text you can copy:
   > I prepared unit, integration, and system tests for the Note-Taking app and documented results in `Test_Report.md`. The test scripts are included and can be executed with Node.js/Jest or via GitHub Actions (CI workflow included).

## Option B — (Recommended) Push to GitHub to run tests automatically
Pushing this repo to GitHub will trigger Actions (CI) and produce real test results — great evidence.

1. Create a new GitHub repository on github.com (do NOT fork). Copy the repo HTTPS URL (e.g., https://github.com/yourusername/notes-testing.git).
2. On your computer, unzip `NoteApp_Testing.zip` and run these commands (replace the remote URL):
   ```bash
   cd NoteApp_Testing
   git init
   git add .
   git commit -m "Add testing artifacts for Week 2 Functional Testing Lab"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
3. After pushing, go to the repository on GitHub and open the "Actions" tab. The workflow `nodejs.yml` will run and report test results.
4. Create Issues: open `GitHub_Issues.md`, copy each Issue into GitHub Issues, and add the label `functional`.
5. Submit the GitHub repo link on the LMS. This shows real CI evidence and proper issue tracking.

## How to run tests locally (if you want to run them)
You need Node.js (v16+ recommended) and npm installed.
```bash
cd NoteApp_Testing
npm install
npm test
```
If tests fail, open `index.html` in a browser and check the console or inspect the code. The tests use `jsdom` and expect your HTML to define elements with IDs: `note-title`, `note-content`, and buttons labelled `Save Note`, and CSS class `.note` for rendered notes.

## Important: Be honest in your submission
- If you cannot run the tests locally, it's fine — push to GitHub to run CI and include the Actions results in your submission.  
- If you upload the ZIP directly, add the short note (in Option A) explaining the tests are prepared. Do **not** claim you ran tests you did not run.

## Need help?
Reply here and I can guide you through any step (unzipping, pushing to GitHub, or creating Issues). If you want, I can also generate the exact `git` commands to use on your machine (tell me your repo URL).
