# 🧪 Functional Testing Report

## 👤 Student Information
- **Full Name:** Doreen Masika
- **Cohort:** May 2025
- **Date:** 3rd June 2025

---

## 1️⃣ Unit Test

### What function did you test?
I tested the `saveNote()` function, which saves a new note by grabbing values from the input fields and displaying them in the notes list.

### What did your test check for?
- That the app shows an alert when the title or content is empty.
- That a valid note (with both title and content) is displayed correctly after clicking **Save Note**.

### Did you find any bugs?
No crash bugs, but I noticed the **alert** pop-up interrupts the testing flow. Also, the app doesn’t clear input fields after saving. This could confuse users.

---

## 2️⃣ Integration & System Tests

### What steps did you test?
1. Typed a title and content.
2. Clicked **Save Note**.
3. Verified the note appeared below.
4. Edited the note.
5. Saved and deleted it.

### What worked well?
- The note saved and displayed instantly after clicking Save.
- Editing worked — the text fields were refilled with the note’s content.
- Deleting a note removed it from the list immediately.

### What didn’t work / Bugs found?
1. **Editing deletes the original note first** — the app removes the note as soon as you click Edit, even before you confirm saving changes.
2. **Delete button has no confirmation** — a single click deletes a note permanently with no warning.
3. **Security risk** — since user input is inserted directly using `innerHTML`, malicious HTML/JS code could run (XSS vulnerability).

---

## 🐞 GitHub Issues Created
I prepared three GitHub issues labeled **functional** (copy the content from `GitHub_Issues.md` into GitHub Issues if you want them live).

| # | Issue Title | Summary |
|---|--------------|----------|
| 1 | Edit removes the original note immediately | When you click "Edit," the note disappears before you re-save, causing potential data loss. |
| 2 | Delete has no confirmation | Clicking "Delete" instantly removes the note with no alert or undo option. |
| 3 | Potential HTML injection | `innerHTML` is used for displaying user notes, allowing script injection. |

---

## 3️⃣ Reflection

### Was anything confusing or hard to test?
Yes — setting up DOM-based testing in Jest is tricky. The functions are all inside the HTML file, so testing needed a fake browser (JSDOM). Simulating real clicks and checking updates was time-consuming.

### How did you figure out what to test?
I followed the user flow from the browser: write → save → display → edit → delete.
Then I looked for what could break or behave unexpectedly.

### What did you learn from this activity?
I learned:
- Unit tests catch **input-level issues** (like empty fields).
- Integration tests reveal **interaction bugs** (like missing updates).
- System tests expose **flow and UX issues**.
Also, functional testing can uncover deeper problems like security risks even in simple apps.

---

## ✅ Summary
| Test Type | Status | Notes |
|------------|---------|-------|
| Unit Test | ✅ Passed | Empty title/content alert works |
| Integration Test | ⚠️ Minor UX bug | Notes display but edit flow deletes originals |
| System Test | ⚠️ Needs improvement | No delete confirmation; XSS risk |

---

### 📋 Conclusion
The note-taking app works but needs **UX and security improvements** before being production-ready. I successfully prepared unit, integration, and system tests, and documented all functional issues with clear GitHub Issues.

**Submitted by:**  
**Doreen Masika**  
_May 2025 Cohort_
