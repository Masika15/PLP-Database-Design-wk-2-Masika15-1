# GitHub Issues (Functional)

Below are the three issues I prepared during functional testing. Copy each title + body into GitHub Issues and add the label `functional`.

---

## Issue 1 — Edit removes the original note immediately (label: functional)

**Steps to reproduce**
1. Open the app (index.html).
2. Create a note (fill Title and Content) and click "Save Note".
3. Click the note's "Edit" button.

**Actual result**
- The note disappears from the list immediately after clicking "Edit".
- If the user decides not to click Save after editing, the original note has been lost.

**Expected result**
- Clicking "Edit" should populate the inputs for editing but must NOT delete the original until the user explicitly clicks "Save".
- Alternatively, show a confirmation or a draft mechanism.

**Severity**
Functional / UX — can cause data loss.

---

## Issue 2 — Delete has no confirmation / no undo (label: functional)

**Steps to reproduce**
1. Create a note (Title + Content) and Save.
2. Click the note's "Delete" button.

**Actual result**
- The note is removed immediately with no confirmation or undo option.

**Expected result**
- Before deleting, show a confirmation dialog (e.g., "Are you sure?") or provide an undo option.

**Severity**
Functional / UX — risk of accidental data loss.

---

## Issue 3 — Potential XSS / HTML injection via note title/content (label: functional)

**Steps to reproduce**
1. In the note Title or Content field enter: <img src=x onerror=alert('XSS')>
2. Click Save Note.
3. The content is injected into the page via innerHTML and may lead to script execution.

**Actual result**
- Browser may execute injected HTML/JS because note text is inserted using innerHTML without sanitization.

**Expected result**
- All displayed note content should be escaped/sanitized before insertion into the page to avoid XSS.

**Severity**
Security / Functional — should be handled before deployment.
